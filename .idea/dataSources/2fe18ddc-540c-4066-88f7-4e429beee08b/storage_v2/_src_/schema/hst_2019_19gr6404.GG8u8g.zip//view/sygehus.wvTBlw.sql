create view sygehus as
select `hst_2019_19gr6404`.`Produkter`.`atc`           AS `atc`,
       `hst_2019_19gr6404`.`Produkter`.`pakningsnavn`  AS `pakningsnavn`,
       `hst_2019_19gr6404`.`Solgte_produkter`.`sektor` AS `sektor`,
       `hst_2019_19gr6404`.`Produkter`.`varenummer`    AS `varenummer`
from (`hst_2019_19gr6404`.`Produkter`
       join `hst_2019_19gr6404`.`Solgte_produkter`
            on ((`hst_2019_19gr6404`.`Produkter`.`varenummer` = `hst_2019_19gr6404`.`Solgte_produkter`.`varenummer`)));

