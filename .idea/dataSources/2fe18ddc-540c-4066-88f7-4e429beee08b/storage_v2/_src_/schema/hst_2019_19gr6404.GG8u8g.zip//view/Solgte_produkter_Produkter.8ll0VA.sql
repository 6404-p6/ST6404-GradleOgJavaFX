create view Solgte_produkter_Produkter as
select `hst_2019_19gr6404`.`Produkter`.`varenummer`                AS `varenummer`,
       `hst_2019_19gr6404`.`Produkter`.`pakningsnavn`              AS `pakningsnavn`,
       `hst_2019_19gr6404`.`Solgte_produkter`.`a3_solgt_pakninger` AS `a3_solgt_pakninger`
from (`hst_2019_19gr6404`.`Produkter`
       join `hst_2019_19gr6404`.`Solgte_produkter`
            on ((`hst_2019_19gr6404`.`Produkter`.`varenummer` = `hst_2019_19gr6404`.`Solgte_produkter`.`varenummer`)))
where ((`hst_2019_19gr6404`.`Produkter`.`atc` like 'L04AX03%') or
       (`hst_2019_19gr6404`.`Produkter`.`atc` like 'L01BA%'));

